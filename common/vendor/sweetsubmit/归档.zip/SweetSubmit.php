<?php
/**
 * @author Bogdan Burim <bgdn2007@ukr.net> 
 */

namespace common\vendor\sweetsubmit;

use Yii;
use yii\base\Model;
use yii\web\View;
use yii\helpers\Html;
use yii\helpers\Json;
use yii\base\Widget;

class SweetSubmit extends Widget
{
    /**
     * @var string $selector
     */
    public $selector;

    /**
     * @var string JS Callback for Daterange picker
     */
    public $callback;
    /**
     * @var array Options to be passed to daterange picker
     */
    public $options = [];
    /**
     * @var array the HTML attributes for the widget container.
     */
    public $htmlOptions = [];

    /**
     * Initializes the widget.
     * If you override this method, make sure you call the parent implementation first.
     */
    public function init()
    {
        if (!isset($this->htmlOptions['id'])) {
            $this->htmlOptions['id'] = $this->getId();
        }
        parent::init();
    }

    /**
     * Renders the widget.
     */
    public function run()
    {
        $this->initLocale();
        $this->initOptions();
    }

    /**
     * Init plugin optins.
     */
    protected function initOptions()
    {
        $view = Yii::$app->view;

        $this->options = [
            'confirmButtonText' => Yii::t('sweetsubmit', 'Ok'),
            'cancelButtonText'  => Yii::t('sweetsubmit', 'Cancel'),
        ];
        $opts = Json::encode($this->options);

        $view->registerJs("yii.sweetSubmitOptions = $opts;", View::POS_END);
    }

    protected function registerPlugin()
    {
        if ($this->selector)
        {
            $this->registerJs($this->selector, $this->options, $this->callback);
        } else {
            $id = $this->htmlOptions['id'];
            echo Html::tag('input', '', $this->htmlOptions);
            $this->registerJs("#{$id}", $this->options, $this->callback);
        }
    }

    protected function registerJs($selector, $options, $callback) {
        $view = $this->getView();

        DateRangePickerAsset::register($view);

        $js   = [];
        $js[] = '$("' . $selector . '").daterangepicker(' . Json::encode($options) . ($callback ? ', ' . Json::encode($callback) : '') . ');';
        $view->registerJs(implode("\n", $js),View::POS_READY);
    }

    /**
     * Init locale.
     */
    protected function initLocale()
    {
        Yii::$app->i18n->translations['sweetsubmit'] = [
            'class'    => 'yii\i18n\PhpMessageSource',
            'basePath' => __DIR__.DIRECTORY_SEPARATOR.'messages',
        ];
    }
}