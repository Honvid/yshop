<?php

/*
 * This file is part of the light/yii2-sweet-submit.
 *
 * (c) lichunqiang <light-li@hotmail.com>
 *
 * This source file is subject to the MIT license that is bundled
 * with this source code in the file LICENSE.
 */

return [
    'Ok'     => '确定',
    'Cancel' => '取消',
];
